<?php
$servername="localhost";
$username="root";
$password="";
$dbname="generateinvoice";
$con=new mysqli($servername,$username,$password,$dbname);
date_default_timezone_set('Asia/Kolkata');
if($con->connect_error)
{
	die("connection error".$con->connect_error);
}
?>