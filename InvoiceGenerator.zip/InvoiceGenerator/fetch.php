<?php 
  include("db.php");
  	$id = $_REQUEST['id'];
  	$select_product = $con->prepare("SELECT * FROM tbl_products WHERE product_id=?");
 	$select_product->bind_param("i",$id);
    $select_product->execute();
    $result = $select_product->get_result();
    $row = $result->fetch_assoc();
    $data = $row;
    echo json_encode($data);
 ?>