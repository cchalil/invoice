<?php 
   include("db.php");
    
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <title>InvoiceGenerator</title>
      <style>
        .result{
         color:red;
        }
        td
        {
          text-align:center;
        }
      </style>
   </head>
   <body>
      <section class="mt-3">
         <div class="container-fluid">
         <h4 class="text-center" style="color:green" id="invg"> Invoice Generator </h4>
         <div class="row">
            <div class="col-md-5  mt-4 " id ="first">
               <table class="table" style="background-color:#f5f5f5;">
                  <thead>
                     <tr>
                        <th>Product</th>
                        <th style="width: 31%">Qty(Kg)</th>
                        <th>Price</th>
                     </tr>
                  </thead>
                  <tbody>
                     <tr>
                        <td style="width:60%">
                           <select name="fruits" id="fruits"  class="form-control">
                           	<option>Select a Product</option>
                              <?php
                              $select_product = $con->prepare("SELECT * FROM tbl_products");
                              $select_product->execute();
                              $result = $select_product->get_result();
                              while($row = $result->fetch_assoc())
                              { 
                                 ?>
                              <option id="<?php echo $row['product_id']; ?>" value="<?php echo $row['product_name']; ?>" class="fruits custom-select">
                                 <?php echo $row['product_name']; ?>
                              </option>
                              <?php  }?>   
                           </select>
                        </td>
                        <td style="width:1%">
                          <input type="number" id="qty" min="0" value="0" class="form-control">
                        </td>
                        <td>
                           <p id="price"></p>
                        </td>
                        <td><button id="add" class="btn btn-primary">Add</button></td>
                     </tr>
                  </tbody>
               </table>
               <div role="alert" id="errorMsg" class="mt-5" >
                 <!-- Error msg  -->
              </div>
            </div>
            <div class="col-md-12  mt-4" style="background-color:#f5f5f5;" id ="second">
               <div class="p-4">
                  <div class="text-center">
                     <h4>Receipt</h4>
                  </div>
                  <div class="row">
                     <div class="col-xs-6 col-sm-6 col-md-6 ">
                        <span id="year"></span> 
                     </div>
                     <div class="col-xs-6 col-sm-6 col-md-6 text-right">                       
                        <button type="submit" id="print" onclick="printPage()">Print</button>
                     </div>
                  </div><br>
                  <div class="row">
                     </span>
                     <table id="receipt_bill" class="table">
                        <thead>
                           <tr>
                              <th> No.</th>
                              <th>Product Name</th>
                              <th>Quantity(KG)</th>
                              <th class="text-center">Price</th>
                              <th class="text-center">Total</th>
                           </tr>
                        </thead>
                        <tbody id="new" >
                          
                        </tbody>
                        <tr>
                           <td> </td>
                           <td> </td>
                           <td> </td>
                           <td class="text-right text-dark" >
                                <h5><strong>Sub Total:  ₹ </strong></h5>
                                <p><strong>Tax (5%) : ₹ </strong></p>
                                <p><strong>Discount(Amount) : ₹ </strong></p>
                           </td>
                           <td class="text-center text-dark" >
                              <h5> <strong><span id="subTotal"></strong></h5>
                              <h5> <strong><span id="taxAmount"></strong>
                              <h5> <input type="number" name="dis" id="dis" style="margin-top: 10px;display: none" onchange='update(this.id);'></h5>
                               <h5> <strong><span id="discount"></strong></h5>
                               <label id="errorMsg1" style="display: none;color: red">Entered Amount is greater than Total</label>
                           </td>
                        </tr>
                        <tr>
                           <td> </td>
                           <td> </td>
                           <td> </td>
                           <td class="text-right text-dark">
                              <h5><strong>Gross Total: ₹ </strong></h5>
                           </td>
                           <td class="text-center text-danger">
                              <h5 id="totalPayment"><strong> </strong></h5>
                               
                           </td>
                       </tr>
                      
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </section>
   </body>
</html>
<script>
   $(document).ready(function(){
     $('#fruits').change(function() {
      var id = $(this).find(':selected')[0].id;
       $.ajax({
          method:'POST',
          url:'fetch.php',
          data:{id:id},
          dataType:'json',
          success:function(data)
            {
               $('#price').text(data.product_rate);
            }
       });
     });
    
     //Adding Items 
     var count = 1;
     $('#add').on('click',function(){
    
        var name = $('#fruits').val();
        var qty = $('#qty').val();
        var price = $('#price').text();
 
        if(qty == 0)
        {
           var erroMsg =  '<span class="alert alert-danger ml-5">Minimum Qty should be 1 or More than 1</span>';
           $('#errorMsg').html(erroMsg).fadeOut(2000);
        }
        else
        {
           billFunction(); 
        }
         
        function billFunction()
          {
          var total = 0;
       
          $("#receipt_bill").each(function () {
          var total =  price*qty;
          var subTotal = 0;
          subTotal += parseInt(total);
          
          var table =   '<tr><td>'+ count +'</td><td>'+ name + '</td><td>' + qty + '</td><td>' + price + '</td><td><strong><input type="hidden" id="total" value="'+total+'">' +total+ '</strong></td></tr>';
          $('#new').append(table)
 
           // Code for Sub Total of Vegitables 
            var total = 0;
            $('tbody tr td:last-child').each(function() {
                var value = parseInt($('#total', this).val());
                if (!isNaN(value)) {
                    total += value;
                }
            });
             $('#subTotal').text(total);
               
            // Code for calculate tax of Subtoal 5% Tax Applied
              var Tax = (total * 5) / 100;
              $('#taxAmount').text(Tax.toFixed(2));
 
             // Code for Total Payment Amount
 
             var Subtotal = $('#subTotal').text();
             var taxAmount = $('#taxAmount').text();
 
             var totalPayment = parseFloat(Subtotal) + parseFloat(taxAmount);
             $('#totalPayment').text(totalPayment.toFixed(2)); // Showing using ID 
             $('#dis').show();
        
         });
         count++;
        } 
       });
           // Code for year 
             
           var currentdate = new Date(); 
             var datetime = currentdate.getDate() + "/"
                + (currentdate.getMonth()+1)  + "/"
                + currentdate.getFullYear();
                $('#year').text(datetime);
     });
   // Code for Calculating Discount
    function update (id)
  {
     
    var total = parseInt($('#totalPayment').text());
    var val =  parseInt(document.getElementById(id).value);
    if(val>total)
    {	  
   		
        $('#errorMsg1').show();
        document.getElementById(id).value = '';

    }
    else
    {
		var discount = total - val;
		$('#totalPayment').text(discount.toFixed(2));
		$('#discount').text(val.toFixed(2));
		document.getElementById(id).value = '';
		document.getElementById("errorMsg1").style.display = "none";
		document.getElementById("dis").style.display = "none";
  	}
  }
   function printPage() {
   	
   	document.getElementById("first").style.display = "none";
   	document.getElementById("print").style.display = "none";
   	document.getElementById("dis").style.display = "none";
    document.getElementById("invg").style.display = "none";
    window.print();
    }
</script>
